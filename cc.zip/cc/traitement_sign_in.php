<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require "account_functions.php";


$err=$email_err=$password_err=$msg="";

if($_SERVER['REQUEST_METHOD']=='POST'){

    //filtrage de deonnees 

    $email = $_POST['email'];
    $password = $_POST['password'];

    if($myuser=sign_in($email,$password)){

        
                
                $_SESSION['user'] = $myuser ;
                $_SESSION['mypanel'] = [] ; 
                $_SESSION['mypanelnb'] = [] ; 
                $_SESSION['date']="" ;
                header("Location:http://localhost/roma/home.php");
                exit();

    }else{

        $err="*email ou mot de passe incorrect";
    }







}




?>