<?php

require "account_functions.php" ;

$err=$nom_err = $prenom_err = $email_err = $password_err = $date_err =$gender_err = $msg = "" ;

if($_SERVER['REQUEST_METHOD']=='POST'){

    //filtrage de donnees 

  $nom = $_POST['nom'];
  $prenom = $_POST['prenom'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $adr = $_POST['adr'];
  $date = $_POST['date'];

    if(!sign_up($nom,$prenom,$email,$password,$adr,$date)){
        $err="";
        $msg="compte cree " ;
    }else{
        $msg="";
        $err="*nous avons un problème" ;
    }













}


?>


